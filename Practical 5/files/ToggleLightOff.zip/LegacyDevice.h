//
// Created by shnai on 2024/10/05.
//

#ifndef UNTITLED1_LEGACYDEVICE_H
#define UNTITLED1_LEGACYDEVICE_H

class LegacyDevice {
public:
    virtual void on()=0;
    virtual void off()=0;
};


#endif //UNTITLED1_LEGACYDEVICE_H
